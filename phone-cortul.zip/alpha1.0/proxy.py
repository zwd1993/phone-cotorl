from proxy_pb2 import Channel, Response, Empty, Proxy
import json
import grpc
from concurrent import futures
import proxy_pb2_grpc
import time
import os
import subprocess
import time

class ProxyServicer(proxy_pb2_grpc.ProxyServiceServicer):
    def __init__(self):
        with open("proxy.json") as f:
            try:
                self.proxies = json.loads(f.read()).get("proxies")
            
            except:
                pass

    def ListProxy(self, request, context):
        print("--- %s" % self.proxies)

        for proxy in self.proxies:
            print("----%s------" % proxy)
            channels = []
            
            for channel in proxy.get("channels"):
                channels.append(Channel(
                    region = channel.get("region"),
                    isp = channel.get("isp"),
                    address = channel.get("address"),
                    bandwith = channel.get("bandwith"),
                    mix = channel.get("mix"),
                    rank = channel.get("rank")
                ))

            yield Proxy(
                type = 1,
                username = proxy.get("username"),
                password = proxy.get("password"),
                channels = channels,
            )

#        yield Proxy(type = 1, username = Username(username = "chong"), password = Password(password = "2312"), channel = channel)

    def SwitchIp(self, request, context):
#zzzh.8866.org
        print(os.system("killall pppd"))
        time.sleep(1)
        print(os.system("pptpsetup --create test --server '222.184.112.110' --username z0614 --password 56 --start"))
        time.sleep(1)        
        print(os.system("route add default ppp0"))        
        return Response()

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers = 10))
    proxy_pb2_grpc.add_ProxyServiceServicer_to_server(ProxyServicer(), server)

    server.add_insecure_port("0.0.0.0:50051")
    server.start()

    while True:
        time.sleep(10000)
if __name__ == "__main__":
    serve()
    
