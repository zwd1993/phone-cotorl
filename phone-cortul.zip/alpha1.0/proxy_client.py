from proxy_pb2 import Empty, Proxy
import proxy_pb2_grpc
import grpc
import json

if __name__ == "__main__":
    channel = grpc.insecure_channel('127.0.0.1:50051')
    stub = proxy_pb2_grpc.ProxyServiceStub(channel)

#    print(stub.SwitchIp(Empty()))
    
    print(stub.SwitchIp(Empty()))
#    for proxy in stub.ListProxy(Empty()):
#        print(proxy)

    
