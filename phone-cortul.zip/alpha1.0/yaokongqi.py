import input_manager_pb2
import replicator_pb2_grpc
import package_manager_pb2
import package_manager_pb2_grpc
import am_pb2_grpc
import am_pb2

import grpc

#packageName = "com.cibn.tv"

packageName = "com.dangbeimarket"
channel = grpc.insecure_channel('10.0.0.9:5555')
inputStub = input_manager_pb2.InputManagerStub(channel)

# stubPm = package_manager_pb2_grpc.PackageManagerStub(channel)
# replicatorStub = replicator_pb2_grpc.ReplicatorStub(channel)
# amStub = am_pb2_grpc.ActivityManagerStub(channel)
# #
# response = stubPm.installPackageLocal(package_manager_pb2.PackageInfo(packageName =packageName ))
# amStub.startActivity(am_pb2.Package(name=packageName, id=0))

while True :
    print("===a===")
    a = input()
    if a == 'w':
        inputStub.injectKey(input_manager_pb2.KeyEvent(code=input_manager_pb2.KEYCODE_DPAD_UP))
        print("up")
    elif a == 's':
        inputStub.injectKey(input_manager_pb2.KeyEvent(code=input_manager_pb2.KEYCODE_DPAD_DOWN))
        print("down")
    elif a == 'a':
        inputStub.injectKey(input_manager_pb2.KeyEvent(code=input_manager_pb2.KEYCODE_DPAD_LEFT))
        print("left")
    elif a == 'd':
        inputStub.injectKey(input_manager_pb2.KeyEvent(code=input_manager_pb2.KEYCODE_DPAD_RIGHT))
        print("right")
    elif a == 'e':
        inputStub.injectKey(input_manager_pb2.KeyEvent(code=input_manager_pb2.KEYCODE_DPAD_CENTER))
        print("enter")
    elif a == 'f':
        inputStub.injectKey(input_manager_pb2.KeyEvent(code=input_manager_pb2.KEYCODE_BACK))
    elif a == 'q':
        break




