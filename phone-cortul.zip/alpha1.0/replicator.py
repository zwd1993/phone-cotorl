import grpc

import package_manager_pb2
import package_manager_pb2_grpc
import input_manager_pb2
import am_pb2_grpc
import am_pb2
import discovery_pb2
import discovery_pb2_grpc
import replicator_pb2
import replicator_pb2_grpc
import time
import random

from time import sleep

from google.protobuf.empty_pb2 import Empty
#package = "io.grpc.android.helloworldexample"
#package = "com.cibn.tv"

#activity = "io.grpc.android.helloworldexample/io.grpc.helloworldexample.HelloworldActivity"

#activity = "chong.me.deviceinfo"
#activity = "com.pptv.tvsports"
activity = "com.cibn.tv"
#activity = "com.cpuid.cpu_z"
#activity = "io.grpc.android.helloworldexample"
#activity = "chong.me.activitytest"
#activity = "com.pplive.androidxl"
#activity = "com.moretv.android"
#activity = "chong.me.deviceinfo"

package_url = "http://10.0.0.9/a.apk"

import json
from replicator_pb2 import DeviceInfo
from google.protobuf import json_format
import requests


target = "10.0.0.9:5555"
#target = "10.0.0.197:5555"
def test():
  with open("test.json") as f:
    content = f.read()
    toJson = json.loads(content)
    build = toJson.get("build")

    message = replicator_pb2.DeviceInfo()
    build_proto = message.build
#    json_format.Parse(json.dumps(toJson), message)
    
#    json_format.Parse(json.dumps(build), build_proto)

    #print(build_proto)
    #print(message)

    request = requests.get("http://120.27.46.123:8080/device/query")
    response = request.json()
    
    json_format.Parse(json.dumps(response), message, ignore_unknown_fields=True)
    
    print(response)
    print(message)
    print(message.display)
    print(message.host)

def fetch_device_template():
    message = replicator_pb2.DeviceInfo()
    
    request = requests.get("http://120.27.46.123:8080/device/query")

    response = request.json()
    
    json_format.Parse(json.dumps(response), message, ignore_unknown_fields=True)

    return message
  

def connect_remote_service(target):
  stubPool = {}
  
  #connect rpc service
  channel = grpc.insecure_channel(target)
  stubPm = package_manager_pb2_grpc.PackageManagerStub(channel)

  stubPool["PM"] = stubPm

  replicatorStub = replicator_pb2_grpc.ReplicatorStub(channel)
  stubPool["REP"] = replicatorStub

  amStub = am_pb2_grpc.ActivityManagerStub(channel)
  stubPool["AM"] = amStub

  return stubPool

def device_properties_fake(device):
  device.wifiBSSID = "44:21:29:37:60:69"
  device.wifiSSID = "hell31245"
  device.macFromSys = "65:33:35:55:%d:83\n" % (random.randint(10,30))
  device.deviceId = "23544213%d49" % (random.randint(0,9))
  device.display = "1920x1024"
  device.wifiIp = "10.0.0.5"
  device.build.SERIAL = "38805557%d8" % (random.randint(0, 9))

  
def device_save(device):
  json = json_format.MessageToJson(device)
#  print(json)
  requests.post("http://120.27.46.123:8080/device/store", data = json)
  

def device_active(device):
  pass


def device_reactive(device):
  pass


def do_simulation_task(packageName):
  pool = connect_remote_service(target)
  
  pm = pool.get("PM")
  am = pool.get("AM")  
  rep = pool.get("REP")

  # for packages in pm.listInstalledPackages(Empty()):
  #   print(packages)

  response = pm.installPackageLocal(package_manager_pb2.PackageInfo(packageName = packageName))

  device = fetch_device_template()

  device.userId = 0
  device.host = target
  device.package = packageName
  device.build.TIME = 1473387488

  device_properties_fake(device)
  
  print(device)
  print(rep.build(device))

#  device_save(device)
  
  am.startActivity(am_pb2.Package(name = packageName, id = 0))
  time.sleep(10)
#  am.stopActivity(am_pb2.Package(name = packageName))
  
if __name__ == '__main__':
  a = 0
  while a <1:
    do_simulation_task("com.cibn.tv")
    #do_simulation_task("com.shafa.market")
    # do_simulation_task("com.pptv.tvsports")
    # do_simulation_task("com.dangbeimarket")
    # do_simulation_task("com.ktcp.video")
    # do_simulation_task('com.gitvdemo.video')
    # do_simulation_task("com.pplive.androidxl")
    #do_simulation_task("lh.oslauncher")

    a = a+ 1