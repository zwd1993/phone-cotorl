import time


def getTime():
    localtime = time.strftime(" %H", time.localtime())

    inttime = int(localtime)
    a = [20, 21, 22]  # 30
    b = [15]  # 35
    c = [0, 17, 18, 19, 23, 24, 14, 16]  # 40
    d = [6, 7, 8, 9, 10]  # 50
    e = [11, 12, 13]  # 55
    f = [1, 2, 3, 4, 5]  # 60

    # if inttime in a:
    #     sleeptime = 300
    # elif inttime in b:
    #     sleeptime = 350
    # elif inttime in c:
    #     sleeptime = 400
    # elif inttime in d:
    #     sleeptime = 500
    # elif inttime in e:
    #     sleeptime = 550
    # elif inttime in f:
    #     sleeptime = 600
    # return sleeptime

    if inttime in a:
        sleeptime = 300
    elif inttime in b:
        sleeptime = 350
    elif inttime in c:
        sleeptime = 400
    elif inttime in d:
        sleeptime = 500
    elif inttime in e:
        sleeptime = 550
    elif inttime in f:
        sleeptime = 600
    return sleeptime



