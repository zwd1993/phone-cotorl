from __future__ import print_function
import grpc
import package_manager_pb2
import package_manager_pb2_grpc
import input_manager_pb2
import am_pb2_grpc
import am_pb2
import replicator_pb2
import replicator_pb2_grpc
from time import sleep
from google.protobuf.empty_pb2 import Empty
import json
from google.protobuf import json_format
import requests
import random
from random import Random
import os
phone = {
    1:'10.0.0.3:5555',
    2:'10.0.0.4:5555',
    3:'10.0.0.5:5555',
    4:'10.0.0.6:5555',
    5:'10.0.0.7:5555',
    6:'10.0.0.8:5555',
    7:'10.0.0.9:5555',
    8:'10.0.0.197:5555'
}
account = [0]*8
recount = [0]*8
ac = {   '10.0.0.3:5555':[1300,0,0,0,0,0,0,0],#优酷
         '10.0.0.4:5555':[1400,0,0,0,0,0,0,0],#全部
         '10.0.0.5:5555':[1200,0,0,0,0,0,0,0],#优酷沙发
         '10.0.0.6:5555':[1200,0,0,0,0,0,0,0],#沙发
         '10.0.0.7:5555':[1200,0,0,0,0,0,0,0],#优酷
         '10.0.0.8:5555':[1200,0,0,00,0,0,0,0],#沙发
         '10.0.0.9:5555':[1200,0,0,0,0,0,00,0],#沙发
         '10.0.0.197:5555':[0,0,0,0,0,0,0,100]
          }
rc = {   '10.0.0.3:5555':[11000,0,0,0,0,0,0,0],
         '10.0.0.4:5555':[10100,000,0,0,000,000,000,0],
         '10.0.0.5:5555':[10100,0,0,0,0,0,0,0],
         '10.0.0.6:5555':[10100,0,0,0,00,0,0,0],
         '10.0.0.7:5555':[10100,0,0,0,0,0,0,0],
         '10.0.0.8:5555':[10100,0,0,0,0,0,0,0],
         '10.0.0.9:5555':[10100,0,0,0,0,0,0,0,0],
         '10.0.0.197:5555': [0, 0, 0, 0, 0, 0, 0, 1000]
         }
packageName = {
    1:'com.cibn.tv',
    2:'com.ktcp.video',
    3:'com.pptv.tvsports',
    4:'com.shafa.market',
    5 :'com.gitvdemo.video',
    6 :"com.pptv.tvsports",
    7: 'com.pplive.androidxl',
    8:'lh.oslauncher'
}
ppapw = ['com.cibn.tv','com.ktcp.video','com.pptv.tvsports','com.dangbeimarket','com.shafa.market','com.gitvdemo.video',"com.pplive.androidxl","lh.oslauncher"]
list = {
    'com.cibn.tv':'-ssdde-e-e---',
    'com.ktcp.video':'-ddd-e-e---',
    'com.pptv.tvsports':'-d-s-e---',
    'com.dangbeimarket':'-bsss-ed-e-e---',
    'com.shafa.market':'dde-dsdee-e---bbbbb',
    'com.gitvdemo.video':'-e--',
    "com.pplive.androidxl":'-e-e---',
 'lh.oslauncher':'-'
}
mode = {
    1:'激活',
    2:'活跃',
    3:'混合',
}
class PHone:
    def random_str(self):
        str = ''
        chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789'
        length = len(chars) - 1
        random = Random()
        for i in range(8):
            str += chars[random.randint(0, length)]
        return str
    def random_mac(self):
        mac = [random.randint(0x00, 0x7f),
               random.randint(0x00, 0x7f),
               random.randint(0x00, 0x7f),
               random.randint(0x00, 0x7f),
               random.randint(0x00, 0xff),
               random.randint(0x00, 0xff)]

        return "%02x:%02x:%02x:%02x:%02x:%02x" % tuple(mac)
    def createNewPhong(self,packageName):
        Serial = str(random.randint(100000000, 999999999))
        DeviceID = str(random.randint(1000000000, 9999999999))
        message = replicator_pb2.DeviceInfo()
        request = requests.get("http://120.27.46.123:8080/device/query?package=%s"%packageName)
        response = request.json()
        json_format.Parse(json.dumps(response), message, ignore_unknown_fields=True)

        device = message
        device.wifiBSSID = PHone.random_mac(self)
        device.wifiSSID = PHone.random_str(self)
        device.macFromSys = PHone.random_mac(self) + '\n'
        device.deviceId = DeviceID
        device.bluetooth = PHone.random_mac(self)
        device.display = "1920x1024"
        device.wifiIp = phone[random.randint(1,7)]
        device.build.SERIAL = Serial
        return device

class reActive:
    retry = 0
    def actKu(self, phoneID):
        message = replicator_pb2.DeviceInfo()
        request = requests.get("http://120.27.46.123:8080/device/kuactivity?host=%s" % phoneID)
        response = request.json()
        json_format.Parse(json.dumps(response), message, ignore_unknown_fields=True)
        
        return message

    def actOther(self,packageName):
        message = replicator_pb2.DeviceInfo()
        request = requests.get("http://120.27.46.123:8080/device/reactive?package=%s"%packageName)
        response = request.json()
        json_format.Parse(json.dumps(response), message, ignore_unknown_fields=True)
        return message

class Save:
    def Ku(self,device):
        json = json_format.MessageToJson(device)
        print("====================save success=================")
        requests.post("http://120.27.46.123:8080/device/ku", data=json)
    def Other(self,device):
        json = json_format.MessageToJson(device)
        print("====================save success=================")
        requests.post("http://120.27.46.123:8080/device/store", data=json)


class Connection:
    def connect_remote_service(self,phoneID):
        stubPool = {}
        # connect rpc service
        channel = grpc.insecure_channel(phoneID)
        stubPm = package_manager_pb2_grpc.PackageManagerStub(channel)
        stubPool["PM"] = stubPm
        replicatorStub = replicator_pb2_grpc.ReplicatorStub(channel)
        stubPool["REP"] = replicatorStub
        amStub = am_pb2_grpc.ActivityManagerStub(channel)
        stubPool["AM"] = amStub
        inputStub = input_manager_pb2.InputManagerStub(channel)
        stubPool["IM"] = inputStub
        return stubPool

class apkAction:
    def startActive(self,packageName,phoneID):
        conn = Connection()
        channel = conn.connect_remote_service(phoneID)
        am = channel.get("AM")
        pm = channel.get("PM")
        rep = channel.get("REP")
        device = PHone().createNewPhong(packageName)
        device.package = packageName
        device.host = phoneID
        device.build.TIME = 1473387488
        device.userId = 0
        rep.build(device)
        print(device)
        am.startActivity(am_pb2.Package(name=packageName, id=0))
        print('start')
        return device
    def ctrl(self,PhongID,list):
            channel = grpc.insecure_channel(PhongID)
            inputStub = input_manager_pb2.InputManagerStub(channel)
            keys = {
                'w':input_manager_pb2.KEYCODE_DPAD_UP,
                's':input_manager_pb2.KEYCODE_DPAD_DOWN,
                'a':input_manager_pb2.KEYCODE_DPAD_LEFT,
                'd':input_manager_pb2.KEYCODE_DPAD_RIGHT,
                'e':input_manager_pb2.KEYCODE_DPAD_CENTER,
                '-':10,
                'm':input_manager_pb2.KEYCODE_MENU,
                'b':input_manager_pb2.KEYCODE_BACK
                }
            for key in list:
                print(key)
                if key != '-':
                    inputStub.injectKey(input_manager_pb2.KeyEvent(code=keys[key]))
                    sleep(1)
                else:
                    sleep(10)
def activation(phoneID,packageName):
    device = apkAction().startActive(packageName=packageName,phoneID=phoneID)
    if packageName != 'com.cibn.tv':
        Save().Other(device=device)
    else:
        Save().Ku(device=device)
def active(phoneID,packageName):
    if packageName == 'com.cibn.tv':
        device = reActive().actKu(phoneID)
    else:
        device = reActive().actOther(packageName)
    if device.package in ppapw:
        conn = Connection()
        channel = conn.connect_remote_service(phoneID)
        rep = channel.get("REP")
        device.userId = 0
        device.host = phoneID

        rep.build(device)
        print(device.package,type(device.package))
        print(device)
        am = channel.get("AM")
        am.startActivity(am_pb2.Package(name=device.package,id=0))
        return 1
    else:
        return 0
def mixing(phoneID,packageName,proportion):
    mix = random.randint(0,100)
    if mix > proportion:
        print(111)
        activation(phoneID=phoneID,packageName=packageName)
    else:
        print(222)
        active(phoneID=phoneID,packageName=packageName)
def mode1(phoneID):
    while True:
        for num in range(1,9):
            try:
                activitynum = account[num-1]
                if activitynum < ac[phoneID][num-1]:
                    activation(phoneID ,packageName[num])
                    apkAction().ctrl(PhongID=phoneID,list=list[packageName[num]])
                    sleep(random.randint(20,30))
                else:
                    pass
            except Exception:
                print('=====================wrong1=============',phoneID, packageName[num])
                pass
def mode2(phoneID):
    while True:
        for num in range(1, 9):
           try:
               ractivitynum = recount[num-1]
               if ractivitynum < rc[phoneID][num-1]:
                    a = active(phoneID=phoneID, packageName=packageName[num])
                    if a!=0:
                        sleep(6)
                        apkAction().ctrl(PhongID=phoneID, list=list[packageName[num]])
                        sleep(random.randint(120,300))
                        recount[num-1] = ractivitynum + 1
                    else:
                        pass
               else:
                   pass
           except Exception:
               print('=======================wrong2================',phoneID, packageName[num])
               pass
def mode3(phoneID):
    while True:
        mix = random.randint(0, 100)
        if mix > 60:
            print(111)
            for num in range(1, 9):
                try:
                    activitynum = account[num - 1]
                    if activitynum < ac[phoneID][num - 1]:
                        activation(phoneID, packageName[num])
                        sleep(10)
                        apkAction().ctrl(PhongID=phoneID,list=list[packageName[num]])
                        activation(phoneID, packageName[num])
                        sleep(10)
                        apkAction().ctrl(PhongID=phoneID, list=list[packageName[num]])

                        sleep(random.randint(5,10 ))
                    else:
                        pass
                except Exception:
                        print('=============wrong1==============', phoneID, packageName[num])
                        pass
        else:
            print(222)
            for num in range(1, 9):
                try:
                    ractivitynum = recount[num - 1]
                    if ractivitynum < rc[phoneID][num - 1]:
                        a = active(phoneID=phoneID, packageName=packageName[num])
                        if a == 1:
                            sleep(10)
                            apkAction().ctrl(PhongID=phoneID, list=list[packageName[num]])
                            sleep(10)
                            recount[num-1] = ractivitynum + 1
                            a = active(phoneID=phoneID, packageName=packageName[num])
                            apkAction().ctrl(PhongID=phoneID, list=list[packageName[num]])
                            sleep(150)
                        else:
                            pass
                    else:
                        pass
                except Exception:
                    print('===============wrong2============',phoneID, packageName[num])
                    pass
def work():
    mode = {
        1: '激活',
        2: '活跃',
        3: '混合',
    }
    print('选择手机')
    print(phone)
    phoneID = phone[int(input())]
    print('选择操作模式')
    print(mode)
    mode = 3
    if mode==1:
        mode1(phoneID)
    elif mode==2:
        mode2(phoneID)
    else:
        mode3(phoneID)
if __name__ == '__main__':
    work()